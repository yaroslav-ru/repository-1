//
//  main.cpp
//  books
//
//  Created by Ярослав on 5/11/20.
//  Copyright © 2020 Ярослав. All rights reserved.
//

#include "book.hpp"
#include <stdio.h>
int main()
{
  // объявление инициализированного объекта
Cbook B={"D.Doncova Cool kids",220};
printf("%s %d\n",B.getName(),B.getPages());
// объявление массива инициализированных объектов
Cbook C[]= {{"D.Doncova For all money",284}, {"D.Doncova Cool bath",408},
{"D.Doncova Ghost in T-short",389}}; for(int i=0;i<3;i++)
printf("%s %d\n",C[i].getName(),C[i].getPages()); return 0;
}
