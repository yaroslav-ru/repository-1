//
//  book.hpp
//  books
//
//  Created by Ярослав on 5/11/20.
//  Copyright © 2020 Ярослав. All rights reserved.
//

#ifndef book_hpp
#define book_hpp//защита от повторной копиляции описания класса(начало)

class Cbook
{
public: char Name [30];
    int Pages;
    char *getName() // метод по умолчанию считается inline
    { // так как его тело описано в классе
        return Name;
    }
    int getPages();//тело метода будет описано в book.cpp
};
#include <stdio.h>

#endif//защита от повторной компиляции описания класса(завершение)


